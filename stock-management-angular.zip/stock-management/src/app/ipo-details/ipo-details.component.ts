import { Component, OnInit } from '@angular/core';
import { IpoDetailsService } from '../service/ipo-details.service';

@Component({
  selector: 'app-ipo-details',
  templateUrl: './ipo-details.component.html',
  styleUrls: ['./ipo-details.component.css']
})

export class IpoDetailsComponent implements OnInit {

  ipoDetails:string[];
   
  constructor(
    private httpClientService:IpoDetailsService
  ) { }

  ngOnInit() {
    this.httpClientService.getIpoDetails().subscribe(
     response =>this.handleSuccessfulResponse(response),
    );
  }

handleSuccessfulResponse(response)
{
    this.ipoDetails=response;
}

}
