import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListCompaniesComponent } from './list-companies/list-companies.component';
import { IpoDetailsComponent } from './ipo-details/ipo-details.component';
import { ImportStockPriceComponent } from './import-stock-price/import-stock-price.component';
import { ListStockExchangeComponent } from './list-stock-exchange/list-stock-exchange.component';

const routes: Routes = [
  {path:'list-companies',component:ListCompaniesComponent},
  {path:'list-ipoDetails',component:IpoDetailsComponent},
  {path:'import-stockprice',component:ImportStockPriceComponent},
  {path:'import-stockexchange',component:ListStockExchangeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
