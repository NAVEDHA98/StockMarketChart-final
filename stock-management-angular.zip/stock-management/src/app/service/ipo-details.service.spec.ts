import { TestBed } from '@angular/core/testing';

import { IpoDetailsService } from './ipo-details.service';

describe('IpoDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IpoDetailsService = TestBed.get(IpoDetailsService);
    expect(service).toBeTruthy();
  });
});
