import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
export class Company{
  constructor(
     public companyCode:number,
     public companyName:string,
     public turnOver:number,
     public ceo:string,
     public boardOfDirectors:string,
     public sectorId:number,
     public briefWriteUp:string,
     public stockPriceId:number,
  ){}
}
@Injectable({
  providedIn: 'root'
})
export class HttpClientService {
  constructor(
    private httpClient:HttpClient
  ) { 
  }
  getCompany()
  {
    console.log("test call");
    return this.httpClient.get<Company[]>('http://localhost:8085/list/companies');
  }
}
