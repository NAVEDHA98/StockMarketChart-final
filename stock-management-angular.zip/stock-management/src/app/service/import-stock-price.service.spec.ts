import { TestBed } from '@angular/core/testing';

import { ImportStockPriceService } from './import-stock-price.service';

describe('ImportStockPriceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ImportStockPriceService = TestBed.get(ImportStockPriceService);
    expect(service).toBeTruthy();
  });
});
