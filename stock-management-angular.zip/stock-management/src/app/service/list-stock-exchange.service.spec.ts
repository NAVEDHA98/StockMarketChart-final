import { TestBed } from '@angular/core/testing';

import { ListStockExchangeService } from './list-stock-exchange.service';

describe('ListStockExchangeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ListStockExchangeService = TestBed.get(ListStockExchangeService);
    expect(service).toBeTruthy();
  });
});
