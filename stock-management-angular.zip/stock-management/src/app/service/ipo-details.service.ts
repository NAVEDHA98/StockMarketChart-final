import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export class IpoPlaned{
  constructor(
    public id:number,
    public companyCode:number,
    public stockExchange:number,
    public pricePerShare:number,
    public totalShare:number,
    public openDateTime:Date,
    public remarks:string,
  ){}
}
@Injectable({
  providedIn: 'root'
})
export class IpoDetailsService {

  constructor(private httpClient:HttpClient
    ) { 
       }
  getIpoDetails()
  {
    console.log("test call");
    return this.httpClient.get<IpoPlaned[]>('http://localhost:8085/ipo/details');
  }     
}
