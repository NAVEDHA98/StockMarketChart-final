import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export class StockExchange{
  constructor(
    public stockExchangeId:number,
    public stockExchangeName:String,
    public brief:String,
    public address:String,
    public remarks:String
    ){}
  
  } 
@Injectable({
  providedIn: 'root'
})
export class ListStockExchangeService {

  constructor(private httpClient:HttpClient) { }
 
 
  getStockExchange()
  {
    console.log("test call");
     return this.httpClient.get<StockExchange[]>('http://localhost:8085/stockExchange/display');
  }
}
