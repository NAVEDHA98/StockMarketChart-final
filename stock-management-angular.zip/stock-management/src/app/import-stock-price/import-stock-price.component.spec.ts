import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportStockPriceComponent } from './import-stock-price.component';

describe('ImportStockPriceComponent', () => {
  let component: ImportStockPriceComponent;
  let fixture: ComponentFixture<ImportStockPriceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportStockPriceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportStockPriceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
