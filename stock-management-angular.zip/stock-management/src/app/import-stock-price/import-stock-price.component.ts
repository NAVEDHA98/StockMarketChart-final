import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ImportStockPriceService } from '../service/import-stock-price.service';

@Component({
  selector: 'app-import-stock-price',
  templateUrl: './import-stock-price.component.html',
  styleUrls: ['./import-stock-price.component.css']
})
export class ImportStockPriceComponent implements OnInit {
  selectedFiles: FileList;
  currentFileUpload: File;
   constructor(private uploadService: ImportStockPriceService) {}
 selectFile(event) {
   this.selectedFiles = event.target.files;
 }

  ngOnInit() {
  }
  upload() {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.uploadService.pushFileToStorage(this.currentFileUpload).subscribe(event => {
     if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
      }
    });
    this.selectedFiles = undefined;
  }
}
