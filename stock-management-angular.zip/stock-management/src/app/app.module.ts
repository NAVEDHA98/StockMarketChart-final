import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListCompaniesComponent } from './list-companies/list-companies.component';
import { HttpClientModule } from '@angular/common/http';
import { IpoDetailsComponent } from './ipo-details/ipo-details.component';
import { ImportStockPriceComponent } from './import-stock-price/import-stock-price.component';
import { ListStockExchangeComponent } from './list-stock-exchange/list-stock-exchange.component';

@NgModule({
  declarations: [
    AppComponent,
    ListCompaniesComponent,
    IpoDetailsComponent,
    ImportStockPriceComponent,
    ListStockExchangeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
