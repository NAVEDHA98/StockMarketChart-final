package com.premium.stc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.premium.stc.dao.StockExchangeDao;
import com.premium.stc.model.StockExchange;

@Service
public class StockExchangeServiceImpl implements StockExchangeService{
	@Autowired
	StockExchangeDao stockExchangeDao;

	public List<StockExchange> getStockExchangeDetails() throws Exception {
		return stockExchangeDao.findAll();
	}

	public StockExchange getAddedStockExchange(StockExchange stockExchange) throws Exception {
		return stockExchangeDao.save(stockExchange);
	}
	
}
